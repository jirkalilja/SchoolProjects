package oope2017ht;
import fi.uta.csjola.oope.lista.*;
import apulaiset.*;
import oope2017ht.omalista.OmaLista;
import oope2017ht.tiedot.Hakemisto;
import oope2017ht.tiedot.Tiedosto;
import oope2017ht.tiedot.Tieto;

/**
 * Tulkki-luokka, joka tulkitsee k�ytt�liittym�lt� saamansa
 * komennot ja hy�dynt�� paketteja oope2017ht.tiedot, oope2017.omalista,
 * apulaiset ja fi.uta.csjola.oope.lista.
 * <p>
 * Harjoitusty�, Olio-ohjelmoinnin perusteet, kev�t 2017.
 * <p>
 * @author Jirka Lilja (lilja.jirka.j@student.uta.fi),
 * Luonnontieteiden tiedekunta, Tampereen yliopisto
 *
 */

public class Tulkki {

   /*
    * Attribuutit
    *
    */

   /** Hakemiston juuri */
   private Hakemisto juuri;

   /** Hakemistossa t�ll� hetkell� k�ytett�v� hakemisto */
   private Hakemisto nykyinen;

   // Setterit ja getterit.

   public Hakemisto juuri(){
      return juuri;
   }

   public void juuri(Hakemisto uusiJuuri) {
      juuri = uusiJuuri;
   }

   public Hakemisto nykyinen(){
      return nykyinen;
   }

   public void nykyinen(Hakemisto uusiNykyinen) {
      nykyinen = uusiNykyinen;
   }

   /*
    * Rakentajat
    * 
    */

   /**
    * 
    * Tulkin rakentaja, joka luo juuren uuteen hakemistoon.
    * 
    */

   public Tulkki() {
      // Luodaan juurihakemisto juurelle ominaiseen alustamisen tekev�ll� rakentajalla.
      juuri = new Hakemisto();

      // Alussa hakemistopuussa on vain juuri.
      nykyinen = juuri;
   }

   /**
    * Luo uuden hakemiston.
    * 
    * @param komento, annettu luotavan hakemiston nimi.
    * @return Palauttaa uuden hakemiston,
    * jos ei voitu luoda, palautetaan false.
    * 
    */

   public boolean luoHakemisto(String komento) {

      if(nykyinen.hae(komento) == null) {
         // Luodaan uusi hakemisto komennon perusteella.
         Hakemisto uusiHakemisto = new Hakemisto(new StringBuilder(komento), nykyinen);
         // Palautetaan p�ivitetty hakemisto.
         return nykyinen.lisaa(uusiHakemisto);
      }
      // Muutoin palautetaan false.
      else {
         return false;
      }

   }

   /**
    * Palaa juureen
    * 
    * @return true, jos voitiin palata juureen,
    * false, jos ei.
    * 
    */

   public boolean vaihdaHakemisto(){

      if(nykyinen != null) {
         // Vaihdetaan juurihakemistoon
         nykyinen = juuri;
         return true;
      }
      // Jos ei voitu menn� juureen, palautetaan false.
      else {
         return false;
      }
   }

   /**
    * Vaihtaa hakemistoa komennon perusteella.
    * 
    * @param komento, annettu hakemisto, johon halutaan siirty�.
    * @return true, jos siirryttiin uuteen hakemistoon,
    * false, jos ei.
    * 
    */

   public boolean vaihdaHaluttuunHakemistoon(String komento){

      if(nykyinen.hae(komento) != null) {
         // Vaihdetaan hakemistoa komennon perusteella.
         // Luodaan apuhakemisto ja sijoitetaan nykyinen siihen
         Hakemisto apuHakemisto = (Hakemisto)nykyinen.hae(komento);
         nykyinen = apuHakemisto;
         return true;
      }
      // Jos ei l�ydetty hakemistoa, palautetaan false.
      else {
         return false;
      }
   }
   
   /**
    * Vaihtaa hakemiston nykyisen hakemiston alihakemistoksi
    * @return true, jos voitiin vaihtaa alihakemistoa, muutoin false
    */
   
   public boolean vaihdaAliHakemistoon(){
      
      if(nykyinen.hakemisto() != null) {
         Hakemisto apuHakemisto = nykyinen.hakemisto();
         nykyinen = apuHakemisto;
         return true;
      }
      else {
         return false;
      }
   }
   
   /**
    * Kutsuu polun muodostajaa
    * @return annaPolku, joka kutsuu metodia
    */
   
   public String annaPolku() {
      // Kutsutaan metodia, aloitetaan nykyhakemistosta.
      return annaPolku(nykyinen);
   }
   
   /**
    * Muodostaa polun 
    * @param tama, t�m� hakemisto
    * @return polku, muodostettu polku
    */
   
   public String annaPolku(Hakemisto tama) {
      
      // Alustetaan polku
      String polku = "";
      
      // Jos nykyinen hakemisto on tyhj�, palautetaan kauttaviiva
      if (tama.hakemisto() == null) {
         polku = "/";
         return polku;
      }
      // Muutoin l�hdet��n muodostamaan polkua
      else {
         // Tarkastetaan, ett� polkua on muodostettavaksi
         while (tama != null) {
            // Lis�t��n polkuun hakemiston nimi, kauttaviiva ja polku
            polku = tama.nimi().toString() + "/" + polku;
            // Sijoitetaan
            tama = tama.hakemisto();
         }
         // Palautetaan muodostettu polku
         return polku;
      }
   }

   /**
    * Luo uuden tiedoston komennon perusteella.
    * 
    * @param komento, annettu luotavan tiedoston nimi.
    * @param koko, annettu tiedoston koko.
    * @return P�ivitetty lista, jos ei voitu luoda
    * tiedostoa, palautetaan false.
    * 
    */

   public boolean luoTiedosto(String komento, int koko) {

      if (nykyinen.hae(komento) == null) {
         // Luodaan uusi tiedosto.
         Tiedosto uusi = new Tiedosto(new StringBuilder(komento), koko);
         // Palautetaan p�ivitetty lista.
         return nykyinen.lisaa(uusi);
      }
      // Jos ei voitu luoda tiedostoa, palautetaan false.
      else {
         return false;
      }
   }

   /**
    * Nime�� halutun tiedoston komennon perusteella.
    * 
    * @param komento, annettu uudelleen nimett�v�n tiedoston nimi.
    * @param uudelleenNimetty, tiedoston uusi nimi.
    * @return true, jos saatiin nimetty� uudelleen,
    * false, jos taas ei.
    * 
    */

   public boolean nimeaUudelleen(String komento, String uudelleenNimetty) {

      // Jos hakemisto l�ytyy.
      if(nykyinen.hae(komento) != null && nykyinen.hae(uudelleenNimetty)== null ) {

         // Luodaan uusi Tieto ja nimet��n se uudelleen
         Tieto uusi = nykyinen.hae(komento);
         uusi.nimi(new StringBuilder(uudelleenNimetty));

         // Poistetaan alkuper�inen nimi
         nykyinen.lisaa(nykyinen.poista(uudelleenNimetty));
         return true;
      }
      // Jos ei voitu muuttaa nime�
      else {
         return false;
      }
   }

   /**
    * Hakee listattavan hakemiston komennon perusteella.
    * 
    * @param komento, annettu.
    * @return true, jos l�ydettiin listattava hakemisto,
    * muutoin false.
    * 
    */

   public boolean listaaHakemisto(String komento) {

      // Jos hakemisto l�ytyy.
      if(nykyinen.hae(komento) != null) {
         return true;
      }
      // Ei l�ytynyt.
      else {
         return false;
      }
   }

   /**
    * Kopioi halutun tiedoston komennon perusteella.
    * 
    * @param komento, annettu kopioitava tiedoston nimi.
    * @param kopio, kopion uusi nimi.
    * @return false, jos ei voitu tehd� kopiota.
    * 
    */

   public boolean kopioiTiedosto(String komento, String kopio) {

      if(nykyinen.hae(komento) != null && nykyinen.hae(kopio) == null && nykyinen.hae(komento) instanceof Tiedosto) {
         // Muutetaan tiedoston nimi Stringiksi ja
         // sijoitetaan tiedoston nimi apumuuttujaan
         String apu = nykyinen.hae(komento).toString();
         // Katkotaan apumuuttuja
         String[] katkottu = apu.split("[ ]");

         // Katkotaan "vanhaa" tiedoston nime�, jotta saadaan sen koko (numero)
         String osa2 = katkottu[1];

         // Muutetaan koko int-muotoiseksi.
         int kopionKoko = Integer.parseInt(osa2);

         // Luodaan uusi (kopio)tiedosto
         Tiedosto uusi = new Tiedosto(new StringBuilder(kopio), kopionKoko);

         // Palautetaan p�ivitetty lista
         return nykyinen.lisaa(uusi);
      }

      // Jos ei voitu kopioida, palautetaan false.
      else {
         return false;
      }
   }

   /**
    * Poistaa halutun tiedoston komennon perusteella.
    * 
    * @param komento, annettu poistettavan tiedoston nimi.
    * @return true, jos saatiin poistettua,
    * false, jos ei saatu poistettua.
    * 
    */
   public boolean poistaTiedosto(String komento) {
      
      // Poistetaan komennon perusteella ja palautetaan tosi
      if(nykyinen.hae(komento) != null) {
         nykyinen.poista(komento);
         return true;
      }
      // Jos ei voitu poistaa, palautetaan false
      else {
         return false;
      }
   }

   /**
    * Listaa rekursiivisesti koko tiedostorakenteen.
    * @param hakemisto, listattava(t) hakemisto(t)
    * @return true kun koko hakemisto on listattu
    * rekursiivisesti
    *
    */

   public boolean listaaRekursiivisesti(Hakemisto hakemisto){
         
      // Luodaan uusi lista, joka s�il�� hakemiston tiedon
      OmaLista lista = (OmaLista)hakemisto.sisalto();

      // Laskuri
      int i = 0;
      
      // K�yd��n hakemiston sis�lt�� l�pi niin kauan kun listaa riitt��.
      while (i < lista.koko()) {
         // Tehd��n tyyppimuunnos
         Tieto tieto = (Tieto)lista.alkio(i);
         // Tulostetaan tiedon merkkijonoesitys kutsumalla polkua.
         System.out.println(annaPolku(hakemisto) + (tieto.toString()));
         // Tarkistetaan onko tieto Hakemistotyyppinen ja kutsutaan t�t� metodia.
         if (tieto instanceof Hakemisto) {
            listaaRekursiivisesti((Hakemisto) tieto);
         }
         // Lis�t��n laskuria
         i++;
      }
      // Palautetaan tosi kun lista on k�yty l�pi ja tulostettu.
      return true;
   }
}