package oope2017ht;
/**
 * Oope2017HT-luokka, joka sis�lt�� main-luokan ja k�ynnist�� koko ohjelman.
 * <p>
 * Harjoitusty�, Olio-ohjelmoinnin perusteet, kev�t 2017.
 * <p>
 * @author Jirka Lilja (lilja.jirka.j@student.uta.fi),
 * Luonnontieteiden tiedekunta, Tampereen yliopisto
 *
 */

public class Oope2017HT {
   
   public static void main (String[] args) {
      
      // Tervehdit��n k�ytt�j��
      System.out.println("Welcome to SOS.");
      
      // Luodaan uusi k�ytt�liittym�.
      Kayttoliittyma kayttoliittyma = new Kayttoliittyma();
      
      // K�ynnistet��n k�ytt�liittym�.
      kayttoliittyma.kaynnista();
      
   }
}