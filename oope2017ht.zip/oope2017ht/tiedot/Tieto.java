package oope2017ht.tiedot;

/**
 * Abstrakti yliluokka Tieto, joka toteuttaa
 * Comparable-rajapinnan.
 * <p>
 * Harjoitusty�, Olio-ohjelmoinnin perusteet, kev�t 2017.
 * <p>
 * @author Jirka Lilja (lilja.jirka.j@student.uta.fi),
 * Luonnontieteiden tiedekunta, Tampereen yliopisto
 *
 */

public abstract class Tieto implements Comparable<Tieto>  {
   
   /*
    * Attribuutit.
    *
    */
   
   /** StringBuilder-tyyppinen muuttuja tiedon nimelle. */
   private StringBuilder nimi;
   
   /** Lippu nimen tarkistamiselle. */
   private boolean tarkastaNimi;

   /*
    * Rakentajat.
    *
    */
   
   public Tieto(){
      nimi = new StringBuilder();
   }
   
   /**
    * Rakentaja Tiedolle.
    *
    * @param uusiNimi, StringBuilder-muotoinen.
    * @throws IllegalArgumentException jos nime� ei voitu asettaa.
    *
    */
   
   public Tieto(StringBuilder uusiNimi) throws IllegalArgumentException {
      
      // Lippu sy�tteen tarkastamiseen
      boolean syoteOk = tarkastaNimi(uusiNimi.toString());
      
      // Jos sy�te oli hyv�ksytt�v�, sijoitetaan
      if (syoteOk == true) { 
         nimi(uusiNimi);
      }
      // Tarvittaessa virheenheitto.
      else {
         throw new IllegalArgumentException();
      }
   }


   /*
    * Aksessorit.
    *
    */
   
   public StringBuilder nimi(){
      return nimi;
   }
   
   public void nimi(StringBuilder uusiNimi) {
      nimi = uusiNimi;
   }
   
   /**
    * Tarkastaa, onko annettu nimi hyv�ksytt�v�ss� muodossa.
    *
    * @param uusiNimi, annettu nimi.
    * @return true, jos nimi oli hyv�ksytt�v� ja false, jos ei ollut hyv�ksytt�v�.
    *
    */
   
   // Tarkastus onko annettu nimi hyv�ksytt�v�
   public boolean tarkastaNimi(String uusiNimi) {
      
      // Jos annettu nimi oli tyhj�, palautetaan heti false
      if(uusiNimi == null) {
         return false;
      }
         //Laskurimuuttuja.
         int j = 0;
         
         // K�yd��n l�pi annetun nimen merkkej�.
         for(int i = 0; i < uusiNimi.length(); i++) {
            // Sijoitetaan apumuuttujaan.
            char merkki = uusiNimi.charAt(i);
            
            // Tarkastetaan, ett� annetussa nimess� on kirjaimia, numeroita tai alaviivoja.
            if((!Character.isLetter(merkki) && !Character.isDigit(merkki)) && (merkki != '_')) {
               // Piste saa esiinty� vain kerran nimess� eik� se saa olla ainoa merkki.
               if(merkki == '.' && uusiNimi.length() != 1) {
                  // Lis�t��n laskuria.
                  j++;
                  
                  // Jos pisteit� useampi kuin yksi, palautetaan ep�tosi.
                  if(j > 1) {
                     return false;
                  }
               }
               // L�ydettiin poikkeama.
               else {
                  return false;
               }
            }
         }
         // Palautetaan tosi kun nimi on k�yty l�pi hyv�ksytysti.
         return true;
   }
   
   /**
    * Syv�kopioinnin toteutus.
    * Sijoitetaan nimi kopioitavaksi.
    * 
    * @param kopioitava tiedosto.
    * 
    */

   public Tieto(Tieto kopioitava) {
      nimi = new StringBuilder(kopioitava.nimi());
   }
   
   /**
    * Toteutetaan Comparable-rajapinnan metodi.
    * Vertaillaan nimi� sen j�lkeen kun ne on
    * muutettu String-muotoisiksi.
    *
    * @param t, Vertailtava tieto.
    * @return Palauttaa vertailutuloksen.
    *
    */
   
   @Override
   public int compareTo(Tieto t) {
       // Muunnetaan vertailtavat nimet String-tyyppisiksi.
       String tamanNimi = nimi.toString();
       String toisenNimi = t.nimi.toString();

       // Hy�dynnet��n String-luokan korvausta.
       return tamanNimi.compareTo(toisenNimi);
   }
   
   /**
     * Korvataan Object-luokan toString-metodi.
     *
     * @return Palauttaa String-muotoisen nimen.
     *
     */
   
   @Override
   public String toString() {
      return nimi.toString(); 
   }
   
   /**
    * Korvataan Object-luokan equals-metodi.
    *
    * @param obj, Objekti
    * @return Palauttaa vertailun tuloksen, virheen sattuessa palautus on false.
    *
    */
   
   @Override
   public boolean equals(Object obj) {
      
      try {

          // Muunnetaan vertailtavat nimet String-tyyppisiksi.
          String tamanNimi = nimi.toString();
          String toisenNimi = ((Tieto)obj).nimi().toString();

          // Oliot ovat samat jos attribuuttien arvot ovat samat.
          return tamanNimi.equals(toisenNimi);
      }
      // Napataan virheet.
      catch (Exception e) {
         return false;
      }
   }
}