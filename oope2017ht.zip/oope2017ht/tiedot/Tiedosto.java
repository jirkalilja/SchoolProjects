package oope2017ht.tiedot;

/**
  * Konkreettinen Tiedosto-luokka,
  * jonka yliluokka on Tieto.
  * <p>
  * Harjoitusty�, Olio-ohjelmoinnin perusteet, kev�t 2017.
  * <p>
  * @author Jirka Lilja (lilja.jirka.j@student.uta.fi),
  * Luonnontieteiden tiedekunta, Tampereen yliopisto
  *
  */

public class Tiedosto extends Tieto {
   
   /*
    * Attribuutit.
    *
    */

   /** Tiedoston koko tavuina. */
   private int kokoTavuina;

   /*
    * Rakentajat.
    *
    */
   
   /**
     * Sijoitetaan tiedostolle nimi ja koko.
     *
     * @param uusiNimi, StringBuilder-muotoinen Tiedoston uusi nimi.
     * @param k, Tiedoston koko tavuina.
     * @throws IllegalArgumentException jos ei voitu sijoittaa.
     *
     */
   
   public Tiedosto(StringBuilder uusiNimi, int k) throws IllegalArgumentException {
      // Kutsutaan yliluokan rakentajaa
      super(uusiNimi);
      
      // Sijoitetaan, jos koko nolla tai suurempi.
      if(k >= 0) {
         kokoTavuina(k);
      }
      // Heitet��n virhe tarvittaessa.
      else {
         throw new IllegalArgumentException();
      }
   }
   /*
    * Aksessorit.
    *
    */
    
   public int kokoTavuina(){
      return kokoTavuina;
   }
   
   public void kokoTavuina(int k) throws IllegalArgumentException {
      try {
         if(k >= 0){
            kokoTavuina = k;
         }
      }
      // Napataan ja heitet��n virheet tarvittaessa.
      catch(Exception e) {
         throw new IllegalArgumentException();
      }
   }
   
   /**
    * Syv�kopioinnin toteutus.
    * Kutsutaan yliluokan rakentajaa ja
    * sijoitetaan tiedosto kopioitavaksi.
    * 
    * @param kopioitavaTiedosto, joka on Tiedosto-muotoinen.
    * 
    */
   
   public Tiedosto(Tiedosto kopioitavaTiedosto) {
      // Kutsutaan yliluokan kopiorakentajaa.
      super(kopioitavaTiedosto);
      kokoTavuina(kopioitavaTiedosto.kokoTavuina());
   }
   
   /**
     * Korvataan Object-luokan toString -metodi.
     *
     * @return Palauttaa tiedoston nimen, v�limerkin ja koon tavuina.
     *
     */

   @Override
   public String toString() {
      return super.toString() + " " + kokoTavuina; 
   }
}