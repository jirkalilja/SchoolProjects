package oope2017ht.tiedot;
import fi.uta.csjola.oope.lista.*;
import apulaiset.*;
import oope2017ht.omalista.OmaLista;

/**
 * Konkreettinen Hakemisto-luokka. Yliluokkana Tieto.
 * Toteuttaa Komennettava-rajapinnan.
 * <p>
 * Harjoitusty�, Olio-ohjelmoinnin perusteet, kev�t 2017.
 * <p>
 * @author Jirka Lilja (lilja.jirka.j@student.uta.fi),
 * Luonnontieteiden tiedekunta, Tampereen yliopisto
 *
 */

public class Hakemisto extends Tieto implements Komennettava<Tieto> {
   
   /*
    * Attribuutit.
    *
    */
   
   /** Omalista-attribuutti */
   private OmaLista lista;
   
   /** Hakemisto-attribuutti, joka viittaa ylihakemistoon */
   private Hakemisto hakemisto;

   /*
    * Rakentajat.
    *
    */
   
   public Hakemisto() {
      hakemisto = null;
      lista = new OmaLista();
   }
   
   /**
    * Rakentaa uuden hakemiston ja hakemistolle uuden nimen.
    *
    * @param uusiNimi, hakemistolle annettu uusi nimi.
    * @param hakemisto1, luotu uusi hakemisto.
    * @throws IllegalArgumentException jos parametreiss� oli virhe.
    */
     
   public Hakemisto(StringBuilder uusiNimi, Hakemisto hakemisto1) throws IllegalArgumentException {
      // Kutsutaan yliluokan rakentajaa.
      super(uusiNimi);
      
      try {
         //Luodaan uusi listaolio ja sijoitetaan hakemistoon.
         lista = new OmaLista();
         hakemisto = hakemisto1;
      }
      // Napataan tarvittaessa virheet.
      catch (IllegalArgumentException e) {
      }
   }

   /*
    * Aksessorit.
    *
    */
   public OmaLista lista() {
      return lista;
   }
   
   public void lista(OmaLista l) {
      lista = l;
   }
   
   public Hakemisto hakemisto() {
      return hakemisto;
   }
   
   public void hakemisto(Hakemisto hakemisto1) {
      hakemisto = hakemisto1;
   }
   
   /**
    * Viite hakemisto-olion osaolioon.
    * 
    * @return palauttaa listan sis�ll�n.
    */

   @Override
   public LinkitettyLista sisalto() {
      return lista;
   }

   /**
    * Hakee tiedon listalta.
    * Tarkistaa, l�ytyyk� tietoa ja k�ytt��
    * apuoliota uuden hakemiston muodostamiseen.
    *
    * @param uusiNimi, haettavan tiedon nimi
    * @return Palauttaa haetun listan,
    * jos ei l�ydetty, palautus on null.
    * 
    */   
   
   @Override
   public Tieto hae(String uusiNimi) {
      // Jos nimi on tyhj�, palautetaan null.
      if(uusiNimi == null) {
         return null;
      }
      // Luodaan apuolio ja luodaan uusi hakemisto
      Hakemisto haettava = new Hakemisto(new StringBuilder(uusiNimi), null);
      // Palautetaan haettava lista.
      return (Tieto)lista.hae(haettava);
   }
   
   /**
    * Lis�� tiedon listalle.
    *
    * @param lisattava, Lis�tt�v� tieto.
    * @return Palauttaa muokatun listan, johon lis�tty tieto,
    * jos ei voitu lis�t�, palautus on false.
    * 
    */
   
   @Override
   public boolean lisaa(Tieto lisattava) {
      // Tarkistetaan, ett� voidaan lis�t�.
      if(lista.hae(lisattava) == null) {
         // Palautetaan muokattu lista.
         return lista.lisaa(lisattava);
      }
      // Muutoin palautetaan ep�tosi.
      else {
         return false;
      }
   }
   
   /**
    * Poistaa tiedon listalta.
    * Tarkistaa, l�ytyyk� poistettava tieto ja k�ytt��
    * apuoliota uuden listan muodostamiseen.
    *
    * @param poistettava tieto.
    * @return Palauttaa muokatun listan, josta poistettu tieto,
    * jos ei voitu poistaa, palautus on null.
    * 
    */
   
   @Override
   public Tieto poista(String poistettava) {
      // Jos poistettavaa ei l�ydy, palautetaan null.
      if(poistettava == null) {
         return null;
      }
      // Luodaan apuolio ja luodaan uusi hakemisto
      Hakemisto haettava = new Hakemisto(new StringBuilder(poistettava), null);
      // Palautetaan muokattu lista.
      return (Tieto)lista.poista(haettava);
   }
    
   /**
    * Korvataan Object-luokan toString -metodi.
    *
    * @return Palauttaa yliluokan hakemiston nimen,
    * kauttaviivan ja listan koon (alihakemistojen m��r�).
    *
    */
   
   @Override
   public String toString() {
      return super.toString() + "/ " + lista.koko();
   }
}