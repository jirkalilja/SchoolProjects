package oope2017ht;
import fi.uta.csjola.oope.lista.*;
import apulaiset.*;
import oope2017ht.omalista.OmaLista;
import oope2017ht.tiedot.Hakemisto;

/**
 * K�ytt�liittym�, joka ohjaa viestit tulkille.
 * Sis�lt�� p��silmukan.
 * <p>
 * Harjoitusty�, Olio-ohjelmoinnin perusteet, kev�t 2017.
 * <p>
 * @author Jirka Lilja (lilja.jirka.j@student.uta.fi),
 * Luonnontieteiden tiedekunta, Tampereen yliopisto
 *
 */

public class Kayttoliittyma {
   
   // Yleiset vakiot
   public static final String KEHOTE = ">";
   public static final String VIRHEILMOITUS = "Error!";
   public static final String LOPETUSTEKSTI = "Shell terminated.";
   public static final String EROTIN = " ";
   
   // Komentovakiot
   public static final String LUOHAKEMISTO = "md";
   public static final String VAIHDAHAKEMISTO = "cd";
   public static final String LUOTIEDOSTO = "mf";
   public static final String NIMEAUUDELLEEN = "mv";
   public static final String LISTAAHAKEMISTO = "ls";
   public static final String KOPIOITIEDOSTO = "cp";
   public static final String POISTA = "rm";
   public static final String LISTAAREKURSIIVISESTI = "find";
   public static final String LOPETAOHJELMA = "exit";
   
   /** Attribuutti tulkille. */
   public Tulkki tulkki;
   
   /*
    * Rakentajat
    * 
    */
   
   public Kayttoliittyma() {
      tulkki = new Tulkki();
      tulkki.nykyinen(); 
   }
   
   // Lippu ohjelman jatkamiselle
   boolean jatketaan = true;
   
   /**
    * K�ynnist�� ja py�ritt�� koko ohjelmaa silmukalla.
    * 
    */

public void kaynnista() {
      
   // Muuttuja k�ytt�j�n antamalle komennolle.
   String komento = "";
         
   do {
      try {
         // L�hdet��n muodostamaan polkua kutsumalla metodia tulkkiluokasta
         System.out.print(tulkki.annaPolku());
         
         // Odotetaan komentoa
         System.out.print(KEHOTE);
         
         // Kysyt��n komentoa.
         komento = In.readString();
         
         // Katkotaan komento osiin.
         String[] osat = komento.split("[ ]");
         
         // Kutsutaan komennon perusteella:
         if (komento.startsWith(LUOHAKEMISTO + EROTIN)) {
            luoHakemisto(osat);
         }
         else if (komento.equals(VAIHDAHAKEMISTO)) {
            vaihdaJuureen();
         }
         else if (komento.startsWith(VAIHDAHAKEMISTO + EROTIN)) {
            vaihdaHakemistoa(osat);
         }
         else if (komento.startsWith(LUOTIEDOSTO + EROTIN)) {
            luoTiedosto(osat);
         }
         else if (komento.startsWith(NIMEAUUDELLEEN + EROTIN)) {
            nimeaUudelleen(osat);
         }
         else if (komento.equals(LISTAAHAKEMISTO)) {
            listaaHakemisto();
         }
         else if (komento.startsWith(LISTAAHAKEMISTO + EROTIN)) {
            listaaTiettyHakemisto(osat);
         }
         else if (komento.startsWith(KOPIOITIEDOSTO + EROTIN)) {
            kopioiTiedosto(osat);
         }
         else if (komento.startsWith(POISTA + EROTIN)) {
            poistaKohde(osat);
         }
         else if (komento.equals(LISTAAREKURSIIVISESTI)) {
            listaaRekursiivisesti();
         }
         // exit-komennolla k��nnet��n lippua ja lopetetaan ohjelma
         else if (komento.equals(LOPETAOHJELMA)){
            jatketaan = false;
         }
         // Tuntemattomalla komennolla tulostetaan virheilmoitus.
         else {
            System.out.println(VIRHEILMOITUS);
         }
      }
      // Napataan virheet ja herjataan
      catch(IllegalArgumentException e) {
         System.out.println(VIRHEILMOITUS);
      }
   }
   // Kysyt��n komentoa uudelleen niin kauan kunnes komento on "exit".
   while (jatketaan);
      // Tulostetaan heipat.
      System.out.println(LOPETUSTEKSTI);
}

   /**
    * md-komennolla luodaan hakemisto.
    * @param osat, eli komento
    */

   public void luoHakemisto(String[] osat) {
      // Tarkistetaan parametrien m��r�
      if (osat.length == 2) {
         // Katkotaan edelleen ja kutsutaan tulkkia
         String uudenHakemistonNimi = osat[1];
         boolean syoteOK = tulkki.luoHakemisto(uudenHakemistonNimi);
      }
      else {
         // Muuten tulostetaan virheilmoitus.
         System.out.println(VIRHEILMOITUS);
      }
   }
   
   /**
    * cd-komennolla palataan juurihakemistoon.
    */

   public void vaihdaJuureen() {
      //Kutsutaan tulkkia.
      boolean syoteOK = tulkki.vaihdaHakemisto();
   }
   
   /**
    * cd-komennolla ja parametrilla vaihdetaan hakemistoa.
    * @param osat, eli komento
    */

   public void vaihdaHakemistoa(String[] osat) {
      // Tarkistetaan parametrien m��r�
      if (osat.length == 2) {
  
         // Katkotaan edelleen
         String tarkasteltavaHakemisto = osat[1];
     
         // Jos komennoksi annetaan cd .. siirryt��n alihakemistoon
         if (tarkasteltavaHakemisto.equals("..")) {
            //Kutsutaan tulkkia.
            boolean syoteOK = tulkki.vaihdaAliHakemistoon();
           
            // Jos ei l�ydetty hakemistoa, tulostetaan virhe
            if(syoteOK == false) {
               System.out.println(VIRHEILMOITUS);
            }
         }
         // Muutoin siirrtyt��n haluttuun hakemistoon
         else {
            // Kutsutaan tulkkia
            boolean syoteOK = tulkki.vaihdaHaluttuunHakemistoon(tarkasteltavaHakemisto);
           
            // Jos ei l�ydetty hakemistoa, tulostetaan virhe
            if(syoteOK == false) {
               System.out.println(VIRHEILMOITUS);
            }
         }
      }
      else {
         // Muuten tulostetaan virheilmoitus.
         System.out.println(VIRHEILMOITUS);
      }
   }
   /**
    * mf-komennolla ja parametreill� luodaan uusi tiedosto.
    * @param osat, eli komento
    */

   public void luoTiedosto(String[] osat) {
      // Tarkistetaan parametrien m��r�
      if (osat.length == 3) {
  
         // Katkotaan edelleen
         String nimi = osat[1];
         String numero = osat[2];
     
         // Yritet��n muuttaa koko int-muotoiseksi ja kutsutaan tulkkia.
         int koko = Integer.parseInt(numero);
         boolean syoteOK = tulkki.luoTiedosto(nimi, koko);
      }
      else {
         // Muuten tulostetaan virheilmoitus.
         System.out.println(VIRHEILMOITUS);
      }
   }
   
   /**
    * mv-komennolla nimet��n tiedosto uudelleen.
    * @param osat, eli komento
    */

   public void nimeaUudelleen(String[] osat) {
     // Tarkistetaan parametrien m��r�
     if (osat.length == 3) {
  
        // Katkotaan edelleen
        String vanhaNimi = osat[1];
        String uusiNimi = osat[2];
     
        // Tarkistetaan ettei uusi nimi ole sama kuin vanha
        if(uusiNimi.equals(vanhaNimi)) {
           System.out.println(VIRHEILMOITUS);
        }
        else {
           //Kutsutaan tulkkia.
           boolean syoteOK = tulkki.nimeaUudelleen(vanhaNimi, uusiNimi);
           
           // Jos ei saatu nimetty�, tulostetaan virhe
           if(syoteOK == false){
              System.out.println(VIRHEILMOITUS);
           }
        }
     }
     else {
        // Muuten tulostetaan virheilmoitus.
        System.out.println(VIRHEILMOITUS);
     }
  }
   /**
    * ls-komennolla listataan koko hakemisto.
    */

   public void listaaHakemisto() {
      // Luodaan uusi lista ja tulostetaan hakemisto kutsumalla k�ytt�liittym�n tulostusoperaatiota
      OmaLista uusiLista = (OmaLista)tulkki.nykyinen().sisalto();
      tulosta(uusiLista);
   }
   
   /**
    * ls-komennolla ja parametrilla listataan haluttu hakemisto.
    * @param osat, eli komento
    */

   public void listaaTiettyHakemisto(String[] osat) {
   
      // Tarkistetaan parametrien m��r�
      if (osat.length == 2) {
   
         // Katkotaan edelleen
         String hakemistonNimi = osat[1];
   
         //Kutsutaan tulkkia.
         boolean syoteOK = tulkki.listaaHakemisto(hakemistonNimi);
      
         // Jos palautus on tosi ja hakemisto l�ytyi
         if (syoteOK == true) {
            // Tulostus
            System.out.println(tulkki.nykyinen().hae(hakemistonNimi));
         }
         // Jos hakemistoa ei l�ytynyt, tulostetaan virheilmoitus
         else if (syoteOK == false) {
            System.out.println(VIRHEILMOITUS);
         }
      }
      else {
         // Muuten tulostetaan virheilmoitus.
         System.out.println(VIRHEILMOITUS);
      }
   }
   
   /**
    * cp-komennolla ja parametrilla kopioidaan haluttu tiedosto.
    * @param osat, eli komento
    */
   
   public void kopioiTiedosto(String[] osat) {
   
      // Tarkistetaan parametrien m��r�
      if (osat.length == 3) {
   
         // Katkotaan edelleen
         String kopioitavanNimi = osat[1];
         String uusiNimi = osat[2];
      
         // Kutsutaan tulkkia.
         boolean syoteOK = tulkki.kopioiTiedosto(kopioitavanNimi, uusiNimi);
            
         if (syoteOK == false) {
            System.out.println(VIRHEILMOITUS);
         }
      }
      else {
         // Muuten tulostetaan virheilmoitus.
         System.out.println(VIRHEILMOITUS);
      }
   }
   
   /**
    * rm-komennolla poistetaan haluttu tiedosto.
    * @param osat, eli komento
    */

   public void poistaKohde(String[] osat) {
      // Tarkistetaan parametrien m��r�
      if (osat.length == 2) {
         // Katkotaan edelleen
         String poistettavanNimi = osat[1];

         // Kutsutaan tulkkia.
         boolean syoteOK = tulkki.poistaTiedosto(poistettavanNimi);
         
         // Jos ei voitu poistaa, herjataan
         if (syoteOK == false) {
            System.out.println(VIRHEILMOITUS);
         }
      }
      else {
         // Muuten tulostetaan virheilmoitus.
         System.out.println(VIRHEILMOITUS);
      }
   }
   
   /**
    * find-komennolla listataan rekursiivisesti koko tiedostorakenne.
    * 
    */

   public void listaaRekursiivisesti() {
      // Kutsutaan tulkkia.
      boolean syoteOK = tulkki.listaaRekursiivisesti(tulkki.nykyinen());
   }
   
   /**
    * Operaatio, joka tulostaa nykyisen hakemiston
    * @param lista, OmaLista
    */

   public static void tulosta(OmaLista lista) {
      // Jos lista ei ole tyhj�...
      if (lista != null) {
         for (int i = 0; i < lista.koko(); i++) {
            // Tulostaa listan alkioittain
            System.out.print(lista.alkio(i));
            if (i < lista.koko())
               System.out.println();
         }
      }
   }
}