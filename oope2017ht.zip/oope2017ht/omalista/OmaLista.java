package oope2017ht.omalista;
import fi.uta.csjola.oope.lista.*;
import apulaiset.*;

/**
 * OmaLista, jonka yliluokkana LinkitettyLista ja joka toteuttaa Ooperoiva-rajapinnan.
 * <p>
 * Harjoitusty�, Olio-ohjelmoinnin perusteet, kev�t 2017.
 * <p>
 * @author Jirka Lilja (lilja.jirka.j@student.uta.fi),
 * Luonnontieteiden tiedekunta, Tampereen yliopisto
 *
 */

public class OmaLista extends LinkitettyLista implements Ooperoiva {
   
   /**
    * Etsii listan l�pi, onko listalla vastaavia olioita
    * Tutkitaan equals-metodilla.
    * 
    * @param haettava alkio.
    * @return Viite l�ydettyyn vastaavaan alkioon,
    * jos ei l�ydetty, palautetaan null.
    * 
    */
   
   public Object hae(Object haettava) {
      
      // Tarkistetaan, ett� haettava l�ytyy ja listalla on tavaraa
      if (haettava != null && onkoTyhja() != true) {
         // K�yd��n listaa l�pi
         for(int i = 0; i < koko; i++) {
            // Jos l�ydettiin vastaava olio...
            if(alkio(i).equals(haettava)) {
               // ...palautetaan viite.
               return alkio(i);
            }
         }
      }
      else {
         // Jos vastaavaa alkiota ei l�ydy, parametri on null-arvoinen tai lista on tyhj�.
         return null;
      }
      // Jos vastaavaa alkiota ei l�ydy, parametri on null-arvoinen tai lista on tyhj�.
      return null;
   }
   
   /**
    * Lis�t��n alkio listalle oikeaan kohtaan:
    * Eli sijoitetaan se kaikkien itse��n pienempien tai yht� suurien alkioiden
    * j�lkeen ja ennen kaikkia itse��n suurempia alkioita.
    * Vertailu tehd��n compareTo-metodilla.
    * 
    * @param uusi lis�tt�v� alkio.
    * @return true, jos lis�ys listalle onnistui,
    * muutoin false.
    * 
    */
   
   // Infotaan k��nt�j�� koodin turvallisuudesta.
   @SuppressWarnings({"unchecked"})
   public boolean lisaa(Object uusi) {
      
      // Jos alkio ei ole tyhj�:
      if(uusi != null) {
         
         // Aloitetaan listan (alku)p��st�.
         Solmu nykyinen = paa();
         
         // Laskurimuuttuja sijainnille
         int sijainti = 0;
         
         // Lippumuuttuja. (Ollaan negatiivisia ja) Arvataan ep�todeksi.
         boolean lisatty = false;
         
         // Etsit��n alkiolle oikea paikka alusta etsien.
         while(nykyinen != null && !lisatty) {
            // Asetetaan nykyiseen alkioon Comparable-tyyppinen viite,
            // jotta voidaan kutsua compareTo-metodia.
            Comparable vertailtava = (Comparable)nykyinen.alkio();

            // L�ydettiin parametrina saatua uutta tietoa suurempi tietoalkio.
            if (vertailtava.compareTo(uusi) > 0) {
               // Lis�t��n alkio laskettuun paikkaan.
               lisaa(sijainti, uusi);
               // Ja k��nnet��n lippu.
               lisatty = true;
            }
            // Siirryt��n seuraavaan solmuun.
            nykyinen = nykyinen.seuraava();
            // Kasvatetaan laskuria.
            sijainti++;
         
         }
         // Jos ei olla lis�tty...
         if(!lisatty) {
            // ...lis�t��n alkio listan loppuun.
            lisaaLoppuun(uusi);
         }
         // Palautetaan true jos lis�ys listalle onnistui.
         return true;
      }
      else {
         // Palautetaan false jos alkiota ei voinut vertailla tai se oli null-arvoinen.
         return false;
      }
   }
   
   /**
    * Poistaa listalta alkion, joita oletetaan olevan yksi kappale.
    * Tarkistus tehd��n equals-metodilla.
    * 
    * @param poistettava alkio.
    * @return palauttaa viitteen poistettuun alkioon, jos alkiota ei l�ydy,
    * parametri on null-arvoinen tai lista on tyhj�, palautetaan null.
    * 
    */

   public Object poista(Object poistettava) {
      
      // Tarkastetaan, ettei lista ole tyhj�.
      if(onkoTyhja() == false) {
         // K�yd��n l�pi listaa.
         for(int i = 0; i < koko(); i++) {
            // Jos l�ydettiin poistettava...
            if (alkio(i).equals(poistettava)) {
               // ...poistetaan alkio.
               Object poistettu = poista(i);
               // Palautetaan viite poistettuun tietoalkioon.
               return poistettu;
            }
         }
         // Poistettavaa alkiota ei l�ydy, parametri on null-arvoinen tai lista on tyhj�.
         return null;
      }
      else {
         // Poistettavaa alkiota ei l�ydy, parametri on null-arvoinen tai lista on tyhj�.
         return null;
      }
   }
}